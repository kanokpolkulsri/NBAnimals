README

This Project for Practicum for Computer Engineering (01204223)
First Semister 2016

NBAnimals
- NBAnimals is a basketball game for all ages. You’ll perceive an amusing and challenging between 2 players. For our virtual devices made by acceleroometers and interesting UI in NBAnimals. 
- This project is a part of Practicum subject of Computer Engineer, Faculty of Engineering, Kasetsart University.

Developer
- Ekarat Sathitwattanasan 5810502504
- Kanokpol Kulsri 5810504361

Directories
- game (process to display on screen)
- usb (get input from firmwire)

Languages
- C
- JAVA

Libraries
- JAVA

Hardwares
- Practicum board v3 (x2)
- Plates (x2)
- GY-61 3-axis Accelerometer Module (x2)
- Button (x2)
- Ribbon cable (x2)